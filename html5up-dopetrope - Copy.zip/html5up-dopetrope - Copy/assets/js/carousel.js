document.addEventListener("DOMContentLoaded", function() {
    const carousel = document.querySelector('.carousel');
    const slides = Array.from(document.querySelectorAll('.carousel-slide'));
    const slideCount = slides.length;
    const gap = parseFloat(getComputedStyle(carousel).gap) || 24; // px fallback
    let slideWidth = 0;

    // Clone slides until the total width is at least 2x the visible area for seamless infinite scroll
    let clonesNeeded = Math.ceil(window.innerWidth / (slides[0].offsetWidth + gap)) + slideCount;
    for (let i = 0; i < clonesNeeded; i++) {
        const clone = slides[i % slideCount].cloneNode(true);
        clone.classList.add('clone');
        carousel.appendChild(clone);
    }

    function updateSlideWidth() {
        slideWidth = slides[0].offsetWidth + gap;
    }

    let pos = 0;
    let animationId;
    let totalSlides = slideCount + clonesNeeded;
    let totalWidth = 0;

    function updateTotalWidth() {
        totalWidth = slideWidth * totalSlides;
    }

    function animate() {
        pos -= 1.2; // px per frame, adjust for speed
        // When the first set of slides is fully out of view, reset position
        if (Math.abs(pos) >= slideWidth * slideCount) {
            pos = 0;
        }
        carousel.style.transform = `translateX(${pos}px)`;
        animationId = requestAnimationFrame(animate);
    }

    window.addEventListener('resize', () => {
        updateSlideWidth();
        updateTotalWidth();
    });

    // Init
    updateSlideWidth();
    updateTotalWidth();
    animate();
});